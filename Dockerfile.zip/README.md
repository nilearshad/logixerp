# companies-api
Companies Vocabulary API

## Environment Variables
The service should be properly configured with following environment variables.

Key | Value | Description
:-- | :-- | :-- 
MONGODB_CONNECTION | mongodb://watstock:watstock123@mongo.wtst.io:27017/vocabulary | MongoDB connection string.
BEARER_TOKEN | kXGqkfZpBdAzS2gW | A token for protected interservice communication.
DEBUG | companies* | Enable debugging.
MAX_FILE_SIZE | 1024 * 1024 * 10 | Maximum file size.

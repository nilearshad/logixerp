import React, { Component } from 'react';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';
import Moment from 'react-moment';
import { render } from 'react-dom';
import toastr from 'toastr';
import 'toastr/build/toastr.min.css';
//import '../css/Table.css';
//import '../../node_modules/react-bootstrap-table/css/react-bootstrap-table.css'

/* Setup Check box on table*/
const selectRowProp = {
  mode: 'checkbox', // single row selection,  
  onSelect: onRowSelect,
  onSelectAll: onSelectAll
}; 
function onRowSelect(row, isSelected, e) {
  let rowStr = '';
 /* for (const prop in row) {
    rowStr += prop + ': "' + row[prop] + '"';
  }*/
  //console.log(JSON.stringify(row));
}


function onSelectAll(isSelected, rows) {
  
  if (isSelected) {
    console.log('Current display and selected data: ');
  } else {
   // console.log('unselect rows: ');
  }
  for (let i = 0; i < rows.length; i++) {
    //console.log(rows[i].id);
  }
}
function dateFormatter(cell: any){
  if (!cell) 
    return "";
  return <Moment format="D MMM YYYY">
                {cell}
            </Moment>;
}
class WayBillOrderTable extends Component {

  constructor(props){
    super(props);   
    this.state = {
      buttonProcessing: false,
      rowIndex: ''
    };
  }
  updateWayBill(propsObj, cell, row, rowIndex){ 
   var obj = this; 
   this.setState({buttonProcessing : true, rowIndex: rowIndex});
   const formdata = {shopName : localStorage.getItem('shopName')  , wayBillInfo: row};
   fetch('http://localhost:5000/update-way-bill',{
        method: 'POST',
        headers: {
            "Content-Type": "application/json; charset=utf-8",
        },
        body: JSON.stringify(formdata)
    }).then(function(response) {
      return response.json();
    }).then(function(res) {
       obj.setState({buttonProcessing : false, rowIndex: ''});
       if(res.status) {
          propsObj.handleTrackingIdEvent(row.order_id);
          toastr.success(res.message, '', {displayDuration:5000});
       }
       else
          toastr.error(res.message, '', {displayDuration:5000});
    });
  }


  /*Button Format Create Way Bill*/
  updateWayBillAction(cell, row, enumObject, rowIndex) {
    return (
       <button 
          type="button" disabled={this.state.buttonProcessing} 
          onClick={() => 
          this.updateWayBill(this.props, cell, row, rowIndex)}
       >
       {  this.state.buttonProcessing && this.state.rowIndex == rowIndex
                  ? <span><i className="fa fa-spinner fa-pulse"/> Update Tracking Number</span>
                    : "Update Tracking Number" }
       </button>
    )
 }

  render() {
    
    return (
      <div>
        <BootstrapTable data={this.props.data} selectRow={ selectRowProp }>
          <TableHeaderColumn isKey dataField='order_id'>
            ID
          </TableHeaderColumn>
          <TableHeaderColumn dataField='order_number'>
            Order No
          </TableHeaderColumn>
          <TableHeaderColumn dataField='waybillNumber'>
            WayBill Number
          </TableHeaderColumn>
          
          <TableHeaderColumn dataField='button' dataFormat={this.updateWayBillAction.bind(this)}
          />
          
        </BootstrapTable>
      </div>
    );
  }
}
 
export default WayBillOrderTable;
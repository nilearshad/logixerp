import './bootstrap/dist/css/bootstrap.min.css';
import './bootstrap/dist/css/bootstrap-theme.min.css';
import 'font-awesome/css/font-awesome.min.css';
import './Order.css';
import React, { Component } from 'react';
//import { NavLink } from 'react-router-dom';
import OrderTable from './OrderTable'
import queryString from 'query-string';
const API_URL = 'http://localhost:8082/';
class Order extends Component {
  // Initialize the state
  constructor(props){
    super(props);
    this.state = {
      orderList: {},
      serviceCheck: false

    }  
    this.handleWayWillGeneratation = this.handleWayWillGeneratation.bind(this);  
  }

  // Fetch the list on first mount
  componentDidMount() {
    const values = queryString.parse(this.props.location.search)
    
    this.getShopOrderList(values);
  }

  getShopOrderList(search){
    let currentObject = this;
    if(search.shop == undefined)
      search.shop = localStorage.getItem('shopName');
    const tokenId = localStorage.getItem('tokenId');
    console.log("Request Url"+API_URL+'inventory/'+search.shop);
    fetch(API_URL+'inventory/'+search.shop,{
        method: 'Get',
        headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": "Bearer kXGqkfZpBdAzS2gW",
        }
    }).then(res => res.json())
    .then( function (orderList) { 
      debugger;
      if( orderList.status == 200 )
         currentObject.setState({ orderList : orderList.orders, serviceCheck: true });
      else
          currentObject.setState({ orderList : [], serviceCheck: true });
     });
  }
  

  handleWayWillGeneratation(rowIndex) {
    console.log("ORDERLIST"+JSON.stringify(this.state));
    var orderList = this.state.orderList;    
    orderList.splice(rowIndex, 1);
    this.setState({orderList: orderList});
  }
  
 
  render() {
    const { orderList, serviceCheck } = this.state;    
    console.log(orderList)
    //localStorage.setItem('shopName', shopInfo.shopName);
    if(!serviceCheck)
      return ( <div className="loader text-center">Please Wait we are fetching information ...........</div> );
    return (
      
      <div className="App">
        <div className="Table-header">
          
        </div>
        <OrderTable data={orderList} afterGerenerateWayBill={this.handleWayWillGeneratation}/>
      </div>
    );
  }
}

export default Order;
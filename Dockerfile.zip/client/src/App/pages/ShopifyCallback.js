import './bootstrap/dist/css/bootstrap.min.css';
import './bootstrap/dist/css/bootstrap-theme.min.css';
import React, { Component } from 'react';
import queryString from 'query-string';
import { FormErrors } from './FormErrors';
console.log(process.env.API_URL);
//import {Form} from 'react-forms-processor';
//import {renderer, FormButton} from 'react-forms-processor-atlaskit';

/*const formfields = [
  {
    "id":   "logix_grid_url",
    "name": "logix_grid_url",
    "type": "text",
    "label": "LogixErp Url",
    "className": "form-control url",
    "placeholder": "LogixErp Url",
    "defaultValue": ""
  },
  {
    "id":   "logix_grid_secure_key",
    "name": "logix_grid_secure_key",
    "type": "text",
    "label": "Secure Key",
    "class": "form-control secure_key",
    "placeholder": "LogixErp Secure Key",
    "defaultValue": ""
  }
];*/
class ShopifyCallback extends Component {
  // Initialize the state
  constructor(props){
    super(props);
    this.state = {
      shopInfo: {},
      serviceCheck: false,
      logixErp_url: '',
      secure_key: '',
      access_key: '',
      formErrors: {logixErp_url: '', secure_key: '', access_key: ''},
      secureKeyValid: false,
      accessKeyValid: false,
      logixErpValid: false,
      formValid: false,
      message: null
    }
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  // Fetch the list on first mount
  componentDidMount() {
    const values = queryString.parse(this.props.location.search)
    console.log(values.shop) // "top"    
   
    if(values.shop != undefined)
      localStorage.setItem('shopName', values.shop);    
    this.ShopifyCallback(this.props.location.search);
  }

  ShopifyCallback = (param) => {
    console.log(param);
    let currentObject = this;
    fetch('http://localhost:8082/shopify/callback'+param)
    .then(res => res.json())
    .then( function(shopInfo) {
        if(shopInfo.status === 200) {
          localStorage.setItem('tokenId', shopInfo.id);
          currentObject.setState({ shopInfo : shopInfo, logixErp_url : ("logixErp_url" in shopInfo ) ? shopInfo.logixErp_url : '', secure_key: ( "secure_key" in shopInfo ) ? shopInfo.secure_key : '', access_key: ( "access_key" in shopInfo ) ? shopInfo.access_key : '', formValid: ("logixErp_url" in shopInfo  && "secure_key" in shopInfo && "access_key" in shopInfo) ? true : false,  serviceCheck: true })
        }
        else
            console.log(JSON.stringify(shopInfo));
      });
  }
  /* Update Input form value */
  handleChange = ( e ) => {
    
    const name = e.target.name;
    const value = e.target.value;
    this.setState({[name]: value, message: null},
                  () => { this.validateField(name, value) });
  };
  handleSubmit(e) {
    let currentObject = this;
    let shopName = localStorage.getItem('shopName'); 
    var formdata = this.state;
    formdata.shopName = shopName;  
    console.log(JSON.stringify(formdata)); 
    e.preventDefault();
    fetch('http://localhost:8082/update/settings',{
        method: 'POST',
        headers: {
            "Content-Type": "application/json; charset=utf-8",
        },
        body: JSON.stringify(formdata)
    }).then(function(response) {
      return response.json();
    }).then(function(res) {
      console.log('Created Gist:', JSON.stringify(res));
      currentObject.setState({ shopInfo : res.data, logixErp_url : ("logixErp_url" in res.data ) ? res.data.logixErp_url : '', secure_key: ( "secure_key" in res.data ) ? res.data.secure_key : '',  serviceCheck: true, message: res.message })
    });
  }

  /* Validate Form Field */
  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let logixErpValid = this.state.logixErp_url;
    let secureKeyValid = this.state.secure_key;
    let accessKeyValid = this.state.access_key;

    switch(fieldName) {
      case 'logixErp_url':
        if(value !== '') {
          logixErpValid = value.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_.~#?&//=]*)/g);
          fieldValidationErrors.logixErp_url = logixErpValid ? '' : ' is invalid';
        }
        else {
          logixErpValid = false;
          fieldValidationErrors.logixErp_url = ' is required';
        }

        break;   
      case 'secure_key':
        secureKeyValid = (value !== '') ? true : false;
        fieldValidationErrors.secure_key = secureKeyValid ? '' : ' is required';
        break; 
      case 'access_key':
        accessKeyValid = (value !== '') ? true : false;
        fieldValidationErrors.access_key = accessKeyValid ? '' : ' is required';
        break;         
      default:
        break;
    }
    this.setState({formErrors: fieldValidationErrors,
                    secureKeyValid: secureKeyValid,
                    logixErpValid: logixErpValid,
                    accessKeyValid: accessKeyValid
                  }, this.validateForm);
  }
  /* Validate Form */
  validateForm() {
    this.setState({formValid: this.state.logixErpValid && this.state.secureKeyValid && this.state.accessKeyValid});
  }
  /* Set Error Class*/
  errorClass(error) {
    return(error.length === 0 ? '' : 'has-error');
  }
  render() {
    const { shopInfo, serviceCheck, message } = this.state;    
    localStorage.setItem('shopName', shopInfo.shopName);
    if(!serviceCheck)
      return null;
    
    return (
      
      <div className="row padding10">

        <div className="col-lg-12 col-md-12 col-sm-12">
            <h2>LogixErp</h2>
            <p>Thank You for using LogixErp!</p>
        </div>
      </div>
    );
  }
}

export default ShopifyCallback;
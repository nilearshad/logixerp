import  React, { Component } from 'react';
//import { Redirect  } from 'react-router-dom';
import queryString from 'query-string';
const nonce = require('nonce')();
const apiKey = '3d99d960fd5759a7e71da11f67d176bc';
//const apiSecret = 'bf0b28be5044f1f92b6fc8512da769d5';
const scopes = 'read_products, read_orders, write_orders, read_product_listings, read_fulfillments, write_fulfillments, read_shipping, write_shipping';
const forwardingAddress = "https://685283e4.ngrok.io";
class Shopify extends Component {
  // Initialize the state
  constructor(props){
    super(props);
    this.state = {
      list: [],
      redirectUri: ''
    }
  }

  // Fetch the list on first mount
  componentDidMount() {
    const values = queryString.parse(this.props.location.search)
    console.log(values.shop) // "top"    
    this.shopifyAuth(values);
  }
  

  shopifyAuth = (param) => {
    console.log(param);
    const state = nonce();
    const callbackUrl = forwardingAddress + '/shopify/callback';
    const redirectUri = 'http://' + param.shop +
      '/admin/oauth/authorize?client_id=' + apiKey +
      '&scope=' + scopes +
      '&state=' + state +
      '&redirect_uri=' + callbackUrl;
    console.log(redirectUri);
    window.location = redirectUri;
    
  }

  render() {
    return (
      <div className="Processing">
          Please Wait we are fetching information
      </div>
    )
  }
}

export default Shopify;
var totalVec = new Array();

function Header(){
  return (
    <h1>Dynamic Table with Checkbox - React</h1>
  )
}

var ListItem = React.createClass({
    getInitialState: function(){
      return {name: this.props.value.name, costo: this.props.value.costo, serviceCheck: this.props.value.checked} 
    },
  
    render: function(){
    return(
      <tr>
        <td className="checkTd"><div className="flexcenter"><input type="checkbox" name="serviceCheck" id={"c" + this.props.value.id} checked={this.state.serviceCheck} onChange={this.handleChange}/><label htmlFor={"c" + this.props.value.id}><span></span></label></div></td>
        <td><input type="text" name="name" value={this.state.name} onChange={this.handleChange} placeholder="Service name..."/></td>
        <td><input type="text" name="costo" value={this.state.costo} onChange={this.handleChange} placeholder="Service price..."/></td>
      </tr>
    )
  },
    
  handleChange: function(event){
    const target = event.target;
    const name = target.name;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    
    this.setState({
      [name]: value
    }, this.calcoloTotale);
  },
  
  componentDidMount: function(){
    var finalValue = 0;
    
    if(this.state.serviceCheck){
       finalValue = this.state.costo * 1.0;   
    }else{
      finalValue = 0;
    }
    
    totalVec[this.props.value.id] = finalValue;
    this.props.updateGlobalTotal();
  },
  
  calcoloTotale: function(){
    var finalValue = 0;
    
    if(this.state.serviceCheck){
       finalValue = this.state.costo * 1.0;   
    }else{
      finalValue = 0;
    }
    
    totalVec[this.props.value.id] = finalValue;
    this.props.updateGlobalTotal();
  }
});
  
  
var Table = React.createClass({
  getInitialState: function(){
    return { totale: 0, checked: false} 
  },
  
  render: function(){
    return(
      <div>
        <table>
          <tr>
            <th className="checkTh"></th>
            <th>Good / Service</th>
            <th>Price €</th> 
          </tr>
          
          {this.props.items.map((prodotto) =>
            <ListItem key={prodotto.id} value={prodotto} updateGlobalTotal={this.updateGlobalTotal}/>
          )}
          
          <tr className="totalTr">
            <td></td>
            <td className="totalText">Total (ex VAT):</td>
            <td className="totalTR">{this.state.totale} €</td>
          </tr>
        </table>
      </div>
    )
  },
  
  updateGlobalTotal: function(){
    var total = 0;
    for(var i = 0; i < this.props.ids; i++){
      total += totalVec[i];
    }
    
    this.setState({totale: total});
  }
  
});

var AddNewRow = React.createClass({
  render: function(){
    return(
      <div>
        <button onClick={this.props.onClick}>+</button>
        Add Service
      </div>
    )
  }
});

var Save = React.createClass({
  render: function(){
    return(
      <div>
        <button onClick={this.props.onClick}>S</button>
        Save
      </div>
    )
  }
});

var Calculator = React.createClass({
  getInitialState: function(){
    return {
      counter: this.props.len, lists: this.props.servizi
    }
  },
  
  render: function(){
    return (
      <div className="container">
        <Header />
        <Table items={this.state.lists} ids={this.state.counter}/>
        <AddNewRow onClick={this.addRow}/>
        <Save onClick={this.saveStat}/>
      </div>
    )
  },
  
  addRow: function(){
    this.setState({counter: this.state.counter + 1});
    var listItem = {id: this.state.counter, product:{name:"", costo: "0"}};
    var allItem = this.state.lists.concat([listItem]);
    this.setState({lists: allItem});
  },
  
  saveStat: function(){
    var _this2 = this;
    $.ajax({
     type: "POST",
      url: "saveJson.php",
      dataType: 'json',
      data: { json: _this2.state.lists }
    });
  }
  
});

var servizi = [{"id": "0", "name": "Example 1", "costo": "49", "checked": "true"},
    {"id": "1", "name": "Example 2", "costo": "20", "checked": "true"},
    {"id": "2", "name": "Example 3", "costo": "100"},
    {"id": "3", "name": "Example 4", "costo": "40", "checked": "true"},
    {"id": "4", "name": "Example 5", "costo": "1130"}];


ReactDOM.render(
  <Calculator servizi={servizi} len={servizi.length}/>,
  document.body
);
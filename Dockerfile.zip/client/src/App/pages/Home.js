import React, { Component } from 'react';
import { FormErrors } from './FormErrors';
//import { Link } from 'react-router-dom';
import queryString from 'query-string';
import toastr from 'toastr';
import 'toastr/build/toastr.min.css';
const nonce = require('nonce')();
const API_URL = 'http://localhost:8082/';
class Home extends Component {
  // Initialize the state
  constructor(props){
    super(props);
    this.state = {
      shopInfo: {},
      serviceCheck: false,
      logixErp_url: '',
      secure_key: '',
      access_key: '',
      formErrors: {logixErp_url: '', secure_key: '', access_key: ''},
      secureKeyValid: false,
      accessKeyValid: false,
      logixErpValid: false,
      formValid: false,
      message: null
    }
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  // Fetch the list on first mount
  componentDidMount() {
    const values = queryString.parse(this.props.location.search)
   
    if(values.shop != undefined)
      localStorage.setItem('shopName', values.shop); 
    else
      values.shop = localStorage.getItem('shopName'); 
    values.tokenId = localStorage.getItem('tokenId');    
    this.getShopInfo(values);
  }

  getShopInfo = (param) => {
    console.log(param);
    var obj = this;
    fetch(API_URL+'info/'+param.shop, { headers: { "Authorization": "Bearer kXGqkfZpBdAzS2gW"}})
    .then(function(response) {
      return response.json();
    }).then(function(shopInfo) { 
       if(shopInfo.status == 200) 
          obj.setState({ shopInfo : shopInfo, logixErp_url : ("logixErpUrl" in shopInfo ) ? shopInfo.logixErpUrl : '', secure_key: ( "logixErpSecureKey" in shopInfo ) ? shopInfo.logixErpSecureKey : '', access_key: ( "logixErpAccessKey" in shopInfo ) ? shopInfo.logixErpAccessKey : '', formValid: ("logixErpUrl" in shopInfo  && "logixErpAccessKey" in shopInfo && "access_key" in shopInfo) ? true : false,  serviceCheck: true })
       
       else
          toastr.error(shopInfo.error_message, '', {displayDuration:1500});
    });
    
  }
  /* Update Input form value */
  handleChange = ( e ) => {
    
    const name = e.target.name;
    const value = e.target.value;
    this.setState({[name]: value, message: null},
                  () => { this.validateField(name, value) });
  };
  handleSubmit(e) {
    let currentObject = this;
    let shopName = localStorage.getItem('shopName'); 
    var formdata = {logixErpUrl: this.state.logixErp_url, logixErpSecureKey: this.state.secure_key, logixErpAccessKey: this.state.access_key};
    //formdata.shopName = shopName;  
     
    console.log(JSON.stringify(formdata)); 
    e.preventDefault();
    fetch(API_URL+this.state.shopInfo.id,{
        method: 'PUT',
        headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": "Bearer kXGqkfZpBdAzS2gW",
        },
        body: JSON.stringify(formdata)
    }).then(function(response) {
      return response.json();
    }).then(function(res) {
      toastr.success(res.message, '', {displayDuration:1500});
      currentObject.setState({ shopInfo : res, logixErp_url : ("logixErpUrl" in res ) ? res.logixErpUrl : '', secure_key: ( "logixErpSecureKey" in res ) ? res.logixErpSecureKey : '', access_key: ( "logixErpAccessKey" in res ) ? res.logixErpAccessKey : '',  serviceCheck: true, message: res.message })
    });
  }

  /* Validate Form Field */
  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let logixErpValid = this.state.logixErp_url;
    let secureKeyValid = this.state.secure_key;
    let accessKeyValid = this.state.access_key;

    switch(fieldName) {
      case 'logixErp_url':
        if(value !== '') {
          logixErpValid = value.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_.~#?&//=]*)/g);
          fieldValidationErrors.logixErp_url = logixErpValid ? '' : ' is invalid';
        }
        else {
          logixErpValid = false;
          fieldValidationErrors.logixErp_url = ' is required';
        }

        break;   
      case 'secure_key':
        secureKeyValid = (value !== '') ? true : false;
        fieldValidationErrors.secure_key = secureKeyValid ? '' : ' is required';
        break; 
      case 'access_key':
        accessKeyValid = (value !== '') ? true : false;
        fieldValidationErrors.access_key = accessKeyValid ? '' : ' is required';
        break;         
      default:
        break;
    }
    this.setState({formErrors: fieldValidationErrors,
                    secureKeyValid: secureKeyValid,
                    logixErpValid: logixErpValid,
                    accessKeyValid: accessKeyValid
                  }, this.validateForm);
  }
  /* Validate Form */
  validateForm() {
    this.setState({formValid: this.state.logixErpValid && this.state.secureKeyValid && this.state.accessKeyValid});
  }
  /* Set Error Class*/
  errorClass(error) {
    return(error.length === 0 ? '' : 'has-error');
  }
  render() {
    const { shopInfo, serviceCheck, message } = this.state;    
    //localStorage.setItem('shopName', shopInfo.shopName);
    if(!serviceCheck)
      return null;
    
    return (
      
      <div className="row padding10">

        <div className="col-lg-6 col-md-6 col-sm-6">
            <h2>Overview</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        </div>

        <div className="col-lg-6 col-md-6 col-sm-6">
          <form onSubmit={this.handleSubmit}>
            <div className="panel panel-default">
              <FormErrors formErrors={this.state.formErrors} />
              
            </div>
            <div className={`form-group ${this.errorClass(this.state.formErrors.logixErp_url)}`}>
              <label>
                LogixErp Url:
              </label>
                <input type="text" className="form-control" placeholder="LogixErp Url" name="logixErp_url" value={  this.state.logixErp_url } onChange={this.handleChange} />
              
            </div>
            <div className={`form-group ${this.errorClass(this.state.formErrors.secure_key)}`}>
              <label>
                Secure Key:
              </label>
                <input type="text" className="form-control" placeholder="Secure Key" name="secure_key" value={this.state.secure_key} onChange={this.handleChange} />
              
            </div>
            <div className={`form-group ${this.errorClass(this.state.formErrors.access_key)}`}>
              <label>
                Access Key:
              </label>
                <input type="text" className="form-control" placeholder="Acess Key" name="access_key" value={this.state.access_key} onChange={this.handleChange} />
              
            </div>
            <input type="submit" className="btn btn-primary" disabled={!this.state.formValid}  value="Submit" />
          </form>
        </div>
      </div>
    );
  }
}
export default Home;
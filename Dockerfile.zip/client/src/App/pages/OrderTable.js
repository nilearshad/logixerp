import React, { Component } from 'react';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';
import Moment from 'react-moment';
import { render } from 'react-dom';
import toastr from 'toastr';
import 'toastr/build/toastr.min.css';
//import '../css/Table.css';
//import '../../node_modules/react-bootstrap-table/css/react-bootstrap-table.css'

/* Setup Check box on table*/
const selectRowProp = {
  mode: 'checkbox', // single row selection,  
  onSelect: onRowSelect,
  onSelectAll: onSelectAll
}; 
function onRowSelect(row, isSelected, e) {
  let rowStr = '';
 /* for (const prop in row) {
    rowStr += prop + ': "' + row[prop] + '"';
  }*/
  console.log(JSON.stringify(row));
}


function onSelectAll(isSelected, rows) {
  
  if (isSelected) {
    console.log('Current display and selected data: ');
  } else {
    console.log('unselect rows: ');
  }
  for (let i = 0; i < rows.length; i++) {
    console.log(rows[i].id);
  }
}
function dateFormatter(cell: any){
  if (!cell) 
    return "";
  return <Moment format="D MMM YYYY">
                {cell}
            </Moment>;
}
class OrderTable extends Component {
  constructor(props){
    super(props);   
    this.state = {
      buttonProcessing: false,
      rowIndex: ''
    };
  }
  genrateWayBill(propsobj, cell, row, rowIndex){
   var obj = this; 
   this.setState({buttonProcessing : true, rowIndex: rowIndex});
   var propobj = propsobj;   
   const formdata = {shopName : localStorage.getItem('shopName')  , orderInfo: row};
   fetch('http://localhost:8082/create-way-bill',{
        method: 'POST',
        headers: {
            "Content-Type": "application/json; charset=utf-8",
        },
        body: JSON.stringify(formdata)
    }).then(function(response) {
      return response.json();
    }).then(function(res) {
      obj.setState({buttonProcessing : false, rowIndex: ''});
      if(res.status) {
          propobj.afterGerenerateWayBill(rowIndex);
          toastr.success(res.message, '', {displayDuration:1500});
       }
       else
          toastr.error(res.message, '', {displayDuration:1500});
        
    });
  }


  genrateMultipleWayBill(){
    if(this.refs.table.state.selectedRowKeys.length > 0){
        const selectedIds = this.refs.table.state.selectedRowKeys;
        const selectedRows = this.refs.table.state.data.filter(d => selectedIds.includes(d.id));
        var obj = this; 
        this.setState({buttonProcessing : true, rowIndex: ''});
        var propobj = this.props;   
        const formdata = {shopName : localStorage.getItem('shopName')  , orderInfo: selectedRows};
      fetch('http://localhost:8082/create-multiple-way-bill',{
        method: 'POST',
        headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": "Bearer kXGqkfZpBdAzS2gW",
        },
        body: JSON.stringify(formdata)
      }).then(function(response) {
        return response.json();
      }).then(function(res) {
          obj.setState({buttonProcessing : false, rowIndex: ''});
      if(res.status) {
        //propobj.afterGerenerateWayBill(rowIndex);
        toastr.success(res.message, '', {displayDuration:1500});
      }
      else
        toastr.error(res.message, '', {displayDuration:1500});

      });
    }
    else
        toastr.error("Please select atleast single row", '', {displayDuration:1500});
  }

  /*Button Format Create Way Bill*/
  wayBillAction(cell, row, enumObject, rowIndex) {
    return (
       <button 
          type="button" disabled={this.state.buttonProcessing}  
          onClick={() => 
          this.genrateWayBill(this.props,cell, row, rowIndex)}
       >
        {  this.state.buttonProcessing && this.state.rowIndex == rowIndex
                  ? <span><i className="fa fa-spinner fa-pulse"/> Generate Way Bill</span>
                    : "Generate Way Bill" }
       </button>
    )
 }
 createCustomBtn = props => {
   
      return (
      <div className='my-custom-class' sizeClass='btn-group-md'>
        
        <button type='button'
          className={ `btn btn-primary` } onClick={() => 
          this.genrateMultipleWayBill()}>
          Generate Waybill
        </button>
      </div>
    );
    
  };

 
  render() {
    const options = {
      btnGroup: this.createCustomBtn
    };
    return (
      <div>
        <BootstrapTable id="orderItem" data={this.props.data} selectRow={ selectRowProp } options = { options } search ref='table'>
          <TableHeaderColumn isKey dataField='id'>
            ID
          </TableHeaderColumn>
          <TableHeaderColumn dataField='email'>
            Order No
          </TableHeaderColumn>
          <TableHeaderColumn dataField='created_at' dataSort={true} dataFormat={dateFormatter}>
            Created At
          </TableHeaderColumn>
          <TableHeaderColumn dataField='button' dataFormat={this.wayBillAction.bind(this)}
          > </TableHeaderColumn>
          
        </BootstrapTable>
      </div>
    );
  }
}
 
export default OrderTable;
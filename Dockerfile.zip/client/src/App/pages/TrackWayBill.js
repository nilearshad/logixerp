import './bootstrap/dist/css/bootstrap.min.css';
import './bootstrap/dist/css/bootstrap-theme.min.css';
import 'font-awesome/css/font-awesome.min.css';
import React, { Component } from 'react';
//import { NavLink } from 'react-router-dom';
import WayBillOrderTable from './WayBillOrderTable'
import queryString from 'query-string';

class TrackWayBill extends Component {
  // Initialize the state
  constructor(props){
    super(props);
    this.state = {
      orderList: {},
      serviceCheck: false

    } 
    this.handleTrackingId = this.handleTrackingId.bind(this);   
  }

  // Fetch the list on first mount
  componentDidMount() {
    const values = queryString.parse(this.props.location.search)
    
    this.getShopOrderList(values);
  }

  getShopOrderList(search){
    if(search.shop == undefined)
      search.shop = localStorage.getItem('shopName');
    else
        localStorage.setItem('shopName', search.shop)
    console.log(JSON.stringify(search.shop));
    fetch('http://localhost:5000/order-with-waybill/'+search.shop,{
        method: 'Get',
        headers: {
            "Content-Type": "application/json; charset=utf-8",
        }
    }).then(res => res.json())
    .then(orderList => this.setState({ orderList : orderList.orders, serviceCheck: true }));
  }
  
  handleTrackingId(order_id) {    
    var orderList = this.state.orderList;    
    delete orderList[order_id];    
    this.setState({orderList: orderList});
  }
 
  render() {
    const { orderList, serviceCheck } = this.state;
    let finalOrderList = [];
    for (const orderItem in orderList ) {
      if(orderList[orderItem].tracking_id == undefined)
        finalOrderList.push(orderList[orderItem]);
    }  
    if(!serviceCheck)
      return ( <div className="loader">Please Wait we are fetching information ...........</div> );
    return (
      
      <div className="App">
        <div className="Table-header">

        </div>
        <WayBillOrderTable data={finalOrderList} handleTrackingIdEvent= {this.handleTrackingId}/>
      </div>
    );
  }
}

export default TrackWayBill;
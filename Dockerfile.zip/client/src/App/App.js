import './bootstrap/dist/css/bootstrap.min.css';
import React, { Component } from 'react';
import { Route, Switch, NavLink } from 'react-router-dom';
import './App.css';
import Home from './pages/Home';
import List from './pages/List';
import Shopify from './pages/Shopify';
import ShopifyCallback from './pages/ShopifyCallback';
import Order from './pages/Order';
import TrackWayBill from './pages/TrackWayBill';

class App extends Component {
  render() {
    const App = () => (
      <div>
        <div className="nav-menu">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <NavLink to="/order" activeClassName="active" className="nav-link btn btn-primary">Orders</NavLink>
            </li>            
            <li className="nav-item ">
              <NavLink to="/track-waybill" className="nav-link btn btn-warning">Track WayBill</NavLink>
            </li>
            <li className="nav-item ">
              <NavLink to="/" className="nav-link btn btn-success">Settings</NavLink>
            </li>
          </ul>
        </div>
        <Switch>
          <Route exact path='/' component={Home}/>
          <Route path='/list' component={List}/>
          <Route path='/shopify/callback' component={ShopifyCallback}/>
          <Route path='/shopify' component={Shopify}/>
          <Route path='/track-waybill' component={TrackWayBill}/>
          <Route path='/order' component={Order}/>
          
        </Switch>
      </div>
    )
    return (
      <Switch>
        <App/>
      </Switch>
    );
  }
}

export default App;